npm-prefix(1) -- Display prefix
===============================

## SYNOPSIS

    npm prefix

## DESCRIPTION

Print the prefix to standard out.

## SEE ALSO

* npm-root(1)
* npm-bin(1)
* npm-folders(5)
* npm-config(1)
* npm-config(7)
* npmrc(5)
