#!/usr/bin/env python

"""
Version.py
"""



# Version string - globally available
__VERSION__ = '0.5-dev'
