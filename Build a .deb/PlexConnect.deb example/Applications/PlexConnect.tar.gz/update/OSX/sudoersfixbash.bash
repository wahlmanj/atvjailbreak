#!/bin/bash

sudo /usr/bin/sudoersfix.bash
