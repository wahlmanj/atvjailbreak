#!/bin/bash

sudo /usr/bin/installer.bash
