#!/bin/bash

sudo /usr/bin/falco.bash
