#!/bin/bash

syslog |grep -i "Wake reason"
