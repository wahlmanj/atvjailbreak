#!/bin/bash

#Discover webserver user
whoami
