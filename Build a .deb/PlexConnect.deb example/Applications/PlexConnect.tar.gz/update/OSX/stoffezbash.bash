#!/bin/bash

sudo /usr/bin/stoffez.bash
