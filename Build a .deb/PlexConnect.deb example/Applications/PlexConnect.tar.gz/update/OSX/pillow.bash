#!/bin/bash

cd /Applications/PlexConnect/update/OSX
yes | ./pillow

echo 'You need to choose a theme to install pillow'
echo 'If you already installed a theme ignore this message'
echo 'Close the terminal window to continue installing...'
