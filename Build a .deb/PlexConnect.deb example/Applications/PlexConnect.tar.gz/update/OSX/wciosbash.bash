#!/bin/bash

sudo /usr/bin/wcios.bash
