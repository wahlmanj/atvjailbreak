#!/bin/bash

sudo /usr/bin/wake.bash
