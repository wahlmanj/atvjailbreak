#!/bin/bash

sudo /usr/bin/loghigh.bash
