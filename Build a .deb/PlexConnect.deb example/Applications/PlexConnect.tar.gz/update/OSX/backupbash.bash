#!/bin/bash

sudo /usr/bin/backup.bash
