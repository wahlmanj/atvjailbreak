#!/bin/bash

sudo /usr/bin/purgesettings.bash
