cd /Applications/PlexConnect
sed -i '' 's/High/Normal/g' Settings.cfg
restartbash.bash
