cd /Applications/PlexConnect

export PATH=/usr/local/git/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin:$PATH 

git fetch

git merge origin
