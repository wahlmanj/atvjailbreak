#!/bin/bash

sudo /usr/bin/restoreatvsettings.bash
