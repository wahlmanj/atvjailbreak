#!/bin/bash

sudo /usr/bin/pmsscan.bash
