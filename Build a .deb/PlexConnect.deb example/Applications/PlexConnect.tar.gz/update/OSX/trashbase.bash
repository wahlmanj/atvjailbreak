chmod -R 777 /Applications/PlexConnect
rm -R /Applications/PlexConnect
