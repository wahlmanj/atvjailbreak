#!/bin/bash

## Shutdown OSX
shutdown -h now
