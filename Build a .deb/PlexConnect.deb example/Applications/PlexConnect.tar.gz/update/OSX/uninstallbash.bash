#!/bin/bash

sudo /usr/bin/uninstall.bash
