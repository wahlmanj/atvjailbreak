#!/bin/bash

echo 'Starting uTorrent...'

sudo /usr/bin/utorrent.bash
