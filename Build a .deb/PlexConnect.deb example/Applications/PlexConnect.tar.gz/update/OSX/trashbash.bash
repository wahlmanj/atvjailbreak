#!/bin/bash

sudo /usr/bin/trash.bash
