#!/bin/bash

sudo /usr/bin/who.bash
