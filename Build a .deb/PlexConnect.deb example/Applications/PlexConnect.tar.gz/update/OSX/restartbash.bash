#!/bin/bash

sudo /usr/bin/restart.bash
