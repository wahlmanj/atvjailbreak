#!/bin/bash

sudo /usr/bin/updategit.bash
