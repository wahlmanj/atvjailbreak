#!/bin/bash

sudo /usr/bin/wcopenplex.bash
