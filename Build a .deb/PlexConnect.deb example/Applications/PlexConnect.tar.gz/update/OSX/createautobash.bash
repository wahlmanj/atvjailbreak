#!/bin/bash

sudo /usr/bin/createauto.bash
