cd /Applications/PlexConnect
sed -i '' 's/Normal/High/g' Settings.cfg
restartbash.bash
