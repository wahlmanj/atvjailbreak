#!/bin/bash

echo 'iTunes quit command sent, allow 20 seconds for itunes to quit if in use...'

sudo /usr/bin/quititunes.bash
