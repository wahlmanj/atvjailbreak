#!/bin/bash

sudo /usr/bin/restore.bash
