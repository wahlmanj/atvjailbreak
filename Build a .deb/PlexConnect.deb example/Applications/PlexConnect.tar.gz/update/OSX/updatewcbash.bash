#!/bin/bash

sudo /usr/bin/updatewc.bash
