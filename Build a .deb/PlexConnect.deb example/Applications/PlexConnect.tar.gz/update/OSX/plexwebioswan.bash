cd /Library/WebServer/CGI-Executables
sed -i '' 's/__PLEXWEBWAN__/http:\/\/24.15.90.216:32400\/web\/index.html#!\/dashboard/g' ios.cgi
