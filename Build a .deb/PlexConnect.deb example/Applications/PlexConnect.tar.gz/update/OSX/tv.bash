#!/bin/bash

#Initiate hide command
hide TeamViewer

# Open TeamViewer
open -a TeamViewer

# Wait for TeamViewer to open
Sleep 5

#Hide TeamViewer
hide TeamViewer
