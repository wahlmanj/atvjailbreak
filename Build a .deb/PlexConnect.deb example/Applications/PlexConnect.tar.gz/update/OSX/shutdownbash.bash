#!/bin/bash

echo 'OSX shutdown command sent...'

sudo /usr/bin/shutdown.bash
