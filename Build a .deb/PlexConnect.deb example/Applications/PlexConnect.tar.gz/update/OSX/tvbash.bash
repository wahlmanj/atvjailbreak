#!/bin/bash

echo 'Starting TeamViewer...'

sudo /usr/bin/tv.bash
