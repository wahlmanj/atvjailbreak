#!/bin/bash

sudo /usr/bin/stop.bash
