#!/bin/bash

sudo /usr/bin/plexwebioswan.bash
