#!/bin/bash

sudo /usr/bin/lock.bash
