#!/bin/bash

echo 'OSX sleep command sent...'

sudo /usr/bin/sleep.bash
