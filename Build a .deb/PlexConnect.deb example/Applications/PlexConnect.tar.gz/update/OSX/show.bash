defaults write com.apple.finder AppleShowAllFiles -bool TRUE ;killall Finder
