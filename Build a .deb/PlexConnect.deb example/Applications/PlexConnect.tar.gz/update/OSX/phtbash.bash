#!/bin/bash

echo 'Starting Plex Home Theater...'

sudo /usr/bin/pht.bash
