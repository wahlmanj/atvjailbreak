#!/bin/bash

quit iTunes
