#!/bin/bash

sudo /usr/bin/wahlmanj.bash
