#!/bin/bash

sudo /usr/bin/pythonkiller.bash
