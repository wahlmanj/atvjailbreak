#!/bin/bash

echo 'Time Machine Backup initiated'

tmutil startbackup
