cp /Applications/PlexConnect/update/OSX/sudoers2 /etc/sudoers
chmod 440 /etc/sudoers
