#!/bin/bash

open /Applications/PlexConnect/update/OSX/Web\ Sharing.prefPane
