#!/bin/bash

sudo /usr/bin/removecerts.bash
