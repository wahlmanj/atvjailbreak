#!/bin/bash

sudo /usr/bin/plexwebios.bash
