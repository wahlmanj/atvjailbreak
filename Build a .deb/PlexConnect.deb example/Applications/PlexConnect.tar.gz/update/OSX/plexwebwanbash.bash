#!/bin/bash

sudo /usr/bin/plexwebwan.bash
