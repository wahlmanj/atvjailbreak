#!/bin/bash

sudo /usr/bin/createcert.bash
