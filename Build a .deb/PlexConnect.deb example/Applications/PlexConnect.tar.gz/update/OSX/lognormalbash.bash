#!/bin/bash

sudo /usr/bin/lognormal.bash
