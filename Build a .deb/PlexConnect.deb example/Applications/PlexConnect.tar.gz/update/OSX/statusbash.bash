#!/bin/bash

sudo /usr/bin/status.bash
