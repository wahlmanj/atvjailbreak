#!/bin/bash

sudo /usr/bin/wclist.bash
