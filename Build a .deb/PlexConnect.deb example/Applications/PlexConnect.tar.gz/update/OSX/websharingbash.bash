#!/bin/bash

sudo /usr/bin/websharing.bash
