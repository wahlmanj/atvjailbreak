#!/bin/bash

sudo /usr/bin/createwsj.bash
