#!/bin/bash

sudo /usr/bin/update.bash
