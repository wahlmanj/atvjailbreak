#!/bin/bash

sudo /usr/bin/createimovie.bash
