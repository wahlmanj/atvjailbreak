#!/bin/bash

# Open Plex Home Theater
open -a Plex\ Home\ Theater
