#!/bin/bash

sudo /usr/bin/restorecerts.bash
