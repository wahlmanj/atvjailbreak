#!/bin/bash

sudo /usr/bin/appweb.bash
