#!/bin/bash

rm /Applications/PlexConnect/assets/certificates/trailers.pem
rm /Applications/PlexConnect/assets/certificates/trailers.key
rm /Applications/PlexConnect/assets/certificates/trailers.cer
echo 'Certs have been deleted'
