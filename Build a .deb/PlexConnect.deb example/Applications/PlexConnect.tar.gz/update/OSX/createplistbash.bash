#!/bin/bash

sudo /usr/bin/createplist.bash
