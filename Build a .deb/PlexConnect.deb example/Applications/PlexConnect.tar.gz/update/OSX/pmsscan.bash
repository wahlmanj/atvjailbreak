#!/bin/bash

/Applications/Plex\ Media\ Server.app/Contents/MacOS/Plex\ Media\ Scanner --scan --refresh

echo 'Plex Media Center library update in process...'
