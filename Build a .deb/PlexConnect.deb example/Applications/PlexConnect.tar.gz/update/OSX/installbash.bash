#!/bin/bash

sudo /usr/bin/install.bash
