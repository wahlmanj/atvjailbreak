#!/bin/bash

sudo /usr/bin/timemachine.bash
