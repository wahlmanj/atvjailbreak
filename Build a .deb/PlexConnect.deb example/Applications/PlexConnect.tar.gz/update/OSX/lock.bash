#!/bin/bash

open -a /System/Library/Frameworks/ScreenSaver.framework/Versions/A/Resources/ScreenSaverEngine.app
echo 'screensaver enabled'
