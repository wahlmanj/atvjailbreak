#!/bin/bash

sudo /usr/bin/plexweblistwan.bash
