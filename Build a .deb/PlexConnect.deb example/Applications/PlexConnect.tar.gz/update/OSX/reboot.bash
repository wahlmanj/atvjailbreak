#!/bin/bash

echo echo 'Reset command sent, some programs may prevent the reboot process..."
reboot
