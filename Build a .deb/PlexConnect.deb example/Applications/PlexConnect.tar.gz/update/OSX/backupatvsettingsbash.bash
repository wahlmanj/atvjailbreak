#!/bin/bash

sudo /usr/bin/backupatvsettings.bash
