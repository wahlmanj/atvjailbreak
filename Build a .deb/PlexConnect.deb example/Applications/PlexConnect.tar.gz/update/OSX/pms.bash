#!/bin/bash

# Open Plex Media Server
open -a Plex\ Media\ Server
