cd /Applications/PlexConnect

if [ -s ATVSettings.cfg ]
then
rm ATVSettings.cfg
fi

if [ -s PlexConnect.log ]
then
rm PlexConnect.log
fi
