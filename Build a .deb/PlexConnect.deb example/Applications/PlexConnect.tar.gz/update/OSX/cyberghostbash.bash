#!/bin/bash

sudo /usr/bin/cyberghost.bash
