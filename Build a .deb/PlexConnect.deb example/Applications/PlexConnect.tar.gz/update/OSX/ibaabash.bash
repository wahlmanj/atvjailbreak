#!/bin/bash

sudo /usr/bin/ibaa.bash
