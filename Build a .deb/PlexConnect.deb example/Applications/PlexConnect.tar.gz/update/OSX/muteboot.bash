#!/bin/bash

## kill startup sound
osascript -e 'set volume with output muted'
