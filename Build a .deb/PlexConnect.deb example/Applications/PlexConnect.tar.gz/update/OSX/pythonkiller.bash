killall -s SIGINT Python
killall -9  Python
