#!/bin/bash
sed -i '' 's/__LOCALIP__/192.168.2.30/g' *xml
