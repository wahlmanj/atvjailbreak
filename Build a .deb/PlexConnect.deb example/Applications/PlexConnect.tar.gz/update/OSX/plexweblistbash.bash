#!/bin/bash

sudo /usr/bin/plexweblist.bash
