#!/bin/bash

##Send sleep command to OSX
pmset sleepnow
