#!/bin/bash

sudo /usr/bin/trashbase.bash
