#!/bin/bash

sudo /usr/bin/reboot.bash


