#!/bin/bash

sudo /usr/bin/wcdefault.bash
