#!/bin/bash

sudo /usr/bin/updater.bash
