#!/bin/bash

echo 'Starting iTunes...'

sudo /usr/bin/itunes.bash
