#!/bin/bash

#Initiate hide command
hide iTunes

# Open itunes
open -a iTunes

# Wait for itunes to open
Sleep 5

#Hide iTunes
hide iTunes
