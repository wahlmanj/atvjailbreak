#!/bin/bash

echo 'Starting Plex Media Server...'

sudo /usr/bin/pms.bash
