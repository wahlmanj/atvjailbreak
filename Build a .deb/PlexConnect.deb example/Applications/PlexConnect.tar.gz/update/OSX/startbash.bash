#!/bin/bash

sudo /usr/bin/start.bash
