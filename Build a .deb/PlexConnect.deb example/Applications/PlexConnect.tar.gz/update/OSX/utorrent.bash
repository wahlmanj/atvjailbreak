#!/bin/bash

# Initiate hide command
hide uTorrent

# Open uTorrent
open -a uTorrent

# Wait for uTorrent to open
Sleep 5

# Hide app
hide uTorrent
