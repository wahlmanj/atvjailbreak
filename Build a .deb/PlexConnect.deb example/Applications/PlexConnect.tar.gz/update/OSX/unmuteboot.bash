#!/bin/bash

## unmute startup sound
osascript -e 'set volume without output muted'
